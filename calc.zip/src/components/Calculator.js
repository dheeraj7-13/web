import React, { useState } from 'react';

function Calculator() {
    const [val, setVal] = useState("");

    return (
        <div className='container'>
            <div className='row'>
                <div className='col-12'>
                    <h1 className='display-5 fw-bolder text-primary'>Simple Calculator</h1>
                </div>
            </div>
            <div>
                <input type='text' value={val} readOnly />
            </div>
            <div>
                <button className='button' value="1" onClick={(e) => setVal(val + e.target.value)}>1</button>
                <button className='button' value="2" onClick={(e) => setVal(val + e.target.value)}>2</button>
                <button className='button' value="3" onClick={(e) => setVal(val + e.target.value)}>3</button>
                <button className='button' value="+" onClick={(e) => setVal(val + e.target.value)}>+</button>
            </div>
            <div>
                <button className='button' value="4" onClick={(e) => setVal(val + e.target.value)}>4</button>
                <button className='button' value="5" onClick={(e) => setVal(val + e.target.value)}>5</button>
                <button className='button' value="6" onClick={(e) => setVal(val + e.target.value)}>6</button>
                <button className='button' value="-" onClick={(e) => setVal(val + e.target.value)}>-</button>
            </div>
            <div>
                <button className='button' value="7" onClick={(e) => setVal(val + e.target.value)}>7</button>
                <button className='button' value="8" onClick={(e) => setVal(val + e.target.value)}>8</button>
                <button className='button' value="9" onClick={(e) => setVal(val + e.target.value)}>9</button>
                <button className='button' value="*" onClick={(e) => setVal(val + e.target.value)}>*</button>
            </div>
            <div>
                <button className='button' onClick={() => setVal("")}>C</button>
                <button className='button' value="0" onClick={(e) => setVal(val + e.target.value)}>0</button>
                <button className='button' onClick={() => {
                    try {
                        const result = new Function('return ' + val)();
                        setVal(result.toString());
                    } catch (error) {
                        setVal("Error");
                    }
                }}>=</button>
                <button className='button' value="/" onClick={(e) => setVal(val + e.target.value)}>/</button>
            </div>
        </div>
    );
}

export default Calculator;
// import React, { useState } from 'react';

// function Calculator() {
//     const [val, setVal] = useState("");

//     const handleClick = (value) => {
//         setVal(prev => prev + value);
//     };

//     const handleClear = () => {
//         setVal("");
//     };

//     const handleCalculate = () => {
//         try {
//             // Evaluate the expression using the Function constructor
//             const result = new Function('return ' + val)();
//             setVal(result.toString());
//         } catch (error) {
//             setVal("Error");
//         }
//     };

//     return (
//         <div className='container'>
//             <div className='row'>
//                 <div className='col-12'>
//                     <h1 className='display-5 fw-bolder text-primary'>Simple Calculator</h1>
//                 </div>
//             </div>
//             <div>
//                 <input type='text' value={val} readOnly />
//             </div>
//             <div className='button-grid'>
//                 <div>
//                     <button onClick={() => handleClick('1')}>1</button>
//                     <button onClick={() => handleClick('2')}>2</button>
//                     <button onClick={() => handleClick('3')}>3</button>
//                     <button onClick={() => handleClick('+')}>+</button>
//                 </div>
//                 <div>
//                     <button onClick={() => handleClick('4')}>4</button>
//                     <button onClick={() => handleClick('5')}>5</button>
//                     <button onClick={() => handleClick('6')}>6</button>
//                     <button onClick={() => handleClick('-')}>-</button>
//                 </div>
//                 <div>
//                     <button onClick={() => handleClick('7')}>7</button>
//                     <button onClick={() => handleClick('8')}>8</button>
//                     <button onClick={() => handleClick('9')}>9</button>
//                     <button onClick={() => handleClick('*')}>*</button>
//                 </div>
//                 <div>
//                     <button onClick={handleClear}>C</button>
//                     <button onClick={() => handleClick('0')}>0</button>
//                     <button onClick={handleCalculate}>=</button>
//                     <button onClick={() => handleClick('/')}>/</button>
//                 </div>
//             </div>
//         </div>
//     );
// }

// export default Calculator;