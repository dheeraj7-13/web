import React, { Component } from 'react';

class Counter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            count: 0
        };
        
        this.updateClick = this.updateClick.bind(this);
    }

    updateClick() {
        this.setState(prevState => ({ count: prevState.count + 1 }));
    }

    render() {
        const { count } = this.state; // Correctly destructuring the count from state
        return (
            <div>
                <h1>
                    <button onClick={this.updateClick}>Visit Click</button>
                    <p>Visited {this.state.count} times</p>
                </h1>
            </div>
        );
    }
}

export default Counter;