import React, { Component } from 'react';

class Message extends Component {
    constructor() {
        super();
        this.state = {
            message: 'Welcome Visitor'
        };
       
        this.changeMessage = this.changeMessage.bind(this);
    }

    changeMessage() {
        this.setState({ message: 'Thanks For Coming' });
    }

    render() {
        return (
            <div>
                <h1>{this.state.message}</h1>
                <button onClick={this.changeMessage.bind(this)}>Change Message</button>
            </div>
        );
    }
}

export default Message;