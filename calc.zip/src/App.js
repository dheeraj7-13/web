import React from 'react';
import logo from './logo.svg';
import './App.css';
import Greet from './components/Greet';
import Message from './components/Message';
import Counter from './components/Counter';
import { Form } from './components/Form';
import Calculator from './components/Calculator';
function App() {
  return (
    <div className="App">
      {/* <Message/> */}
      {/* <Counter/> */}
     {/* <Greet name="Vaibhav" surname=" Katkar"/>
     <Greet name="Shruti" surname=" Katkar"/>
     <Greet name="Vani" surname=" Katkar"/> */}
     {/* <Form/> */}
      <Calculator/>
     
    </div>
  );
}

export default App;
